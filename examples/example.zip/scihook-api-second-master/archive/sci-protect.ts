import { utils } from "../../prexpress 2.0";

var presets = {
    level_1:{
        reset_date:Date.now() + utils.get_date(10,'min'),
        timeout:Date.now() + utils.get_date(10,'min'),
        max:5
    },
    level_2:{
        reset_date:Date.now() + utils.get_date(1,'h'),
        timeout:Date.now() + utils.get_date(1,'h'),
        max:10
    },
    level_3:{
        reset_date:Date.now() + utils.get_date(1,'day'),
        timeout:Date.now() + utils.get_date(1,'day'),
        max:20
    },
    level_4:{
        reset_date:Date.now() + utils.get_date(1,'week'),
        timeout:Date.now() + utils.get_date(1,'week'),
        max:40
    }
};

var preset_list = Object.keys(presets);

function setup(ip) {
    var data = {
        IP:ip,
        total:1,
        overload_total:0
    };
    return new Promise<object>((resolve, reject) => {
        preset_list.syncFor( function(preset,next) {
            data[preset] = {
                count:1,
                overload:0,
                reset_date:presets[preset].reset_date
            };
            next();
        },() => {
            resolve(data);
        }) 
    });
}

function set_ip(attempts,ip) {

    var IP_addresses = attempts.IP_addresses;

    return new Promise<void>((resolve, reject) => {

        IP_addresses.syncFor(function (IP,next_ip) {
            
            if (IP.IP == ip) {

                var i = IP_addresses.indexOf(IP);
                var now = Date.now();

                IP_addresses[i].total += 1;

                preset_list.syncFor(function (preset,next_prest) {

                    if (now > presets[preset].timeout) {
                        IP_addresses[i].timeout = false;
                    }

                    if (now > IP_addresses[i][preset].reset_date) {
                        IP_addresses[i][preset].count = 1;
                        IP_addresses[i][preset].reset_date = presets[preset].reset_date;
                    }else{

                        IP_addresses[i][preset].count += 1;

                        if (IP_addresses[i][preset].count >= presets[preset].max) {
                            IP_addresses[i].timeout = true;
                            IP_addresses[i].timeout_time = presets[preset].timeout;
                            IP_addresses[i][preset].count = 0;
                            IP_addresses[i][preset].overload += 1; 
                            IP_addresses[i].overload_total += 1;
                        }

                    }

                    next_prest();
                },resolve);

            }else{
                next_ip();
            }

        },async () => {
            //sadece hiç giriş yapmaya çalışmamış ise çalışıyor.
            IP_addresses.push(await setup(ip));
            resolve();
        });
    });
}

function check_ip(ips,ip) {
    return new Promise<{status:boolean,timeout?:number}>((resolve, reject) => {
        ips.syncFor(function (IP,next_ip) {
            if (IP.IP == ip) {
                if (IP.timeout) {
                    if (IP.timeout_time > Date.now()) {
                        resolve({status:false,timeout:IP.timeout_time - Date.now()});
                    }else{
                        resolve({status:true});
                    }
                }else{
                    resolve({status:true});
                }
            }else{
                next_ip();
            }
        },() => {
            resolve({status:true});
        });
    })
}


export function sci_protect() {

    return async (req,res,next) => {
        
        var user = res.user;
        var sci_protect = user.sci_protect;

        var status = await check_ip(sci_protect.IP_addresses,req.ip);
        if (!status.status) {
            return res.json({
                status:status.status,
                timeout:(status.timeout ? ((status.timeout/1000)/60) + ' min' : 0)
            });
        }

        if (!res.password) {
            await set_ip(sci_protect,req.ip);
            user.save();

            res.send(false)
        }else{
            next();
        }
    }
}