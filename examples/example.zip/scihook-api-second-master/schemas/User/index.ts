import {Schema , model} from 'mongoose';

import {schema as sci_protect} from './sci_protect';
import {schema as sessions} from './sessions';
import {schema as settings} from './settings';
import {schema as personal_informations} from './personal_informations';
import {schema as social_media} from './social_media';
import {schema as emails} from './emails';

var user = new Schema({
    ID:String,
    username:String,
    created_at:Number,
    sessions:[sessions],
    name:String,
    surname:String,
    date_of_birth:String,
    linked_scihook_accounts:Object,
    profile_photo:String,
    jwt_session_id:String,
    emails:[emails],
    settings,
    password:String,
    personal_informations,
    social_media,
    verified:Boolean,
    registiration_IP:String,
    sci_protect
});

export const User =  model('Users' , user);