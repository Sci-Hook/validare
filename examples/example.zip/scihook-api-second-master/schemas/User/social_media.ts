import {Schema } from 'mongoose';

export var schema = new Schema({
    bilimetri:String,
    twitter:String,
    contact_emails:Object,
    instagram:String,
    websites:Object,
    youtube:String,
    wikimedia:String,
    github:String
});