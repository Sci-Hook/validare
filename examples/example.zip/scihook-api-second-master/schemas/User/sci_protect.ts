import {Schema } from 'mongoose';

export var schema = new Schema({
    count:Number,
    IP_addresses:[{
        IP:String,
        timeout_time:Number,
        count:Number,
        level:Number,
        banned:Boolean
    }]
});