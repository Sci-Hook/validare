import {Schema } from 'mongoose';

export var schema = new Schema({
    email:String,
    verified:Boolean,
    last_change_date:Number,
    change_limit:Number,
    type:String
});