import {Schema} from 'mongoose';

export var schema = new Schema({
    theme:String,
    display_lang:String
});