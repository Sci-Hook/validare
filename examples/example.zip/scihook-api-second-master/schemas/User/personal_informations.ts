import {Schema } from 'mongoose';

export var schema = new Schema({
    gender:String,
    phone:String,
    address:String,
    occupation:String,
    orcid_ID:String,
    university:String,
    about:String
});