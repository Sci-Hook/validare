import {Schema} from 'mongoose';

export var schema = {
    IP:String,
    sessions_ID:String,
    active:Boolean
};