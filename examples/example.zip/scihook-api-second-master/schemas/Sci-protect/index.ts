import {Schema , model} from 'mongoose';

var sci_protect = new Schema({
    IP:String,
    timeout_time:Number,
    banned:Boolean,
    user_agents:Object
});

export const Protecter =  model('Protecter' , sci_protect); 