import {Schema , model} from 'mongoose';

import {schema as whitelist} from './whitelist';
import {schema as blacklist} from './blacklist';
import {schema as IPs_using} from './IPs_using';

var key = new Schema({
    user_ID:String,
    key:String,
    number_of_uses:Number,
    whitelist,
    blacklist,
    IPs_using,
    name:String
});

export const Key =  model('Key' , key);