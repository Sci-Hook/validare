import {Schema} from 'mongoose';

export var schema = new Schema({
    IP:String,
    number_of_uses:Number
});