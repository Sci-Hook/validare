import {Schema} from 'mongoose';

export var schema = new Schema({
    IP:String,
    attempt_to_connect:Number
});