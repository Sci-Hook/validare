import {Schema , model} from 'mongoose';

var statistic = new Schema({
    date:Number,
    new_account:Number,
    daily_visit:Number,
    permanent_banned_accounts:Number,
    pass_change_accounts:Number,
    email_change_accounts:Number,
    new_location_accounts:Number,
    suspicious_accounts:Number,
    update_profile_accounts:Number
});

export const Statistic =  model('Statistics' , statistic);