import {Schema , model} from 'mongoose';

var code = new Schema({
    code:String,
    user_ID:String,
    ID:String,
    type:String,
    limit:Number,
    IP:String,
    create_date:Number,
    expires:Number,
    mail:String
});

export const Code =  model('Codes' , code);