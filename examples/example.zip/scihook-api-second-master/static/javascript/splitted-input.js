$(function () {
    $('[queue]').keydown(function (e) {
        console.log(e.key)
        if (e.key == 'Backspace' ) {
            var current_queue = Number($(this).attr('queue'));
            $(this).val('');
            var before_queue = current_queue-1;
            var parent_name = $(this).parent().attr('splitted-input');
            $(`[splitted-input="${parent_name}"] [queue="${before_queue}"]`).focus();
        }else if(e.key == 'ArrowLeft'){
            var current_queue = Number($(this).attr('queue'));
            var before_queue = current_queue-1;
            var parent_name = $(this).parent().attr('splitted-input');
            $(`[splitted-input="${parent_name}"] [queue="${before_queue}"]`).focus();    
        }else if(e.key == 'ArrowRight'){
            var current_queue = Number($(this).attr('queue'));
            var next_queue = current_queue+1;
            var parent_name = $(this).parent().attr('splitted-input');
            $(`[splitted-input="${parent_name}"] [queue="${next_queue}"]`).focus();
        }else{
            if ($(this).val() != '' & $(this).val()  != ' '){
                var current_queue = Number($(this).attr('queue'));
                var next_queue = current_queue+1;
                var parent_name = $(this).parent().attr('splitted-input');
                $(`[splitted-input="${parent_name}"] [queue="${next_queue}"]`).focus();
            }
        }
    })
});