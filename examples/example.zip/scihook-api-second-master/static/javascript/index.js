Array.prototype.syncFor = function (callback, ending_function) {
    var _this = this;
    return new Promise(function (resolve, reject) {
        var index = -1;
        var next = function () {
            index++;
            if (_this.length > index) {
                if (_this.length > 0) {
                    callback(_this[index], next, index + 1, _this.length);
                }
            }
            else {
                if (ending_function)
                    ending_function();
            }
        };
        next();
    });
};
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

var link = document.querySelector("link[rel~='icon']");
if (!link) {
    link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
}
link.href = 'http://127.0.0.1:5500/favicon.ico';


var loadFile = function (event) {
    var image = document.getElementById("output");
    image.src = URL.createObjectURL(event.target.files[0]);
};
  
$(function () {
    $('#slide-left').click(function () {
        var scrollLeft = $(this).parent().scrollLeft() - 200; 
        $(this).parent().animate({
            scrollLeft
        }, 100);  
    })
    $('#slide-right').click(function () {
        var scrollLeft = $(this).parent().scrollLeft() + 200; 
        $(this).parent().animate({
            scrollLeft
        }, 100);    
    })
});