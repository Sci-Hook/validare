var turn_type = {
    number:(x) => {return Number(x)}
}

$(function () {
    $('[send-form]').click(async function () {

        var name = $(this).attr('send-form');
        var form_datas = $(`${name} [name]`).toArray();
        var error = $(`${name}`).attr('error');
        var data_error_modal = $(`${name}`).attr('data-error-modal');
        var data = {};

        form_datas.syncFor(function (form_data,next_data) {
            var name = $(form_data).attr('name');
            var value = $(form_data).val();
            var type = $(form_data).attr('data-type');

            if (type) {
                if (turn_type[type]) {
                    if (value != null && value != undefined) {
                        var value = turn_type[type](value);
                    }
                }
            }
            
            data[name] = value;
            next_data();
        }, () => {

            return fetch('/api/user/register', {
                method: 'POST',
                headers: { 
                    'Content-type': 'application/json'
                },
                body: JSON.stringify(data)
            }).then(res => res.json())
            .then(data => {
                if (data.status) {
                    $(`${data_error_modal} .message-container`).html(data.msg);
                    const myModal = new bootstrap.Modal(data_error_modal, {keyboard: false});
                    myModal.show();
                }else{  
                    $(error).html('');
                    $(error).append(`<div class="alert alert-danger scihook-alert" role="alert"><span id="form-error">${data.msg}</span></div>`)
                    var invalid_values = data.data;
                    invalid_values.forEach(value => {
                        var selector = $(`[name="${value.data_name}"]`).attr('error');
                        $(`[name="${value.data_name}"]`).addClass('danger-border');
                        $(selector).text(value.error);
                    });
                }
            });
        })
    });

    $('input').keyup(function () {
        var error = $(this).attr('error');
        $(error).text('');
        $(this).removeClass('danger-border');
    });
    
});