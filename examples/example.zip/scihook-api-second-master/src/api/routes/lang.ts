import * as express from 'express';
import {validator,create_cookie} from '../../../prexpress-v3';
export var route = express.Router();

route.get('/set' , 
    validator(['lang','redirect']),
    create_cookie([{key:'location',value:'lang'}],2,'year'),
    (req,res,next) => {
        res.redirect(req.query.redirect);
    }
);

