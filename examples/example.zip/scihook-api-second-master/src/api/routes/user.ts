import {User} from '../../../schemas/User';
import {Code} from '../../../schemas/Codes';
import {auth_user} from '../middlewares/security/auth';
import * as express from 'express';
import {validator,db,create_id, jwt,create_cookie,create_html,send_email,hasher,auth,check_condition, send_response} from '../../../prexpress-v3';
export var route = express.Router();

//controller
import {controller as register} from '../controller/register';
import {controller as verify_email} from '../controller/verify-email';
import {controller as login} from '../controller/login';
//controller

//middlewares
import { protecter } from '../middlewares/security/Sci-Protecter';
import { create_mailcode } from '../middlewares/mailcode/create-mail-code';
import { check_mailcode } from '../middlewares/mailcode/check-mail-code';
//middlewares

route.post('/register', 
    validator(['username','email','password','name',
        {key:'password',value:'verify-password'},
        {key:'month',value:'birth-month'},
        {key:'day',value:'birth-day'},
        {key:'year',value:'birth-year'},
    ]),
    db.validate_count(User,[{key:'registiration_IP',value:'req.ip'}],'max_user_of_ip',{max:3}),
    db.validate_notexist(User,['username','email'],'already_exist',{type:'or'}),
    create_id(['user_id','jwt_session_id','sessions_ID']),
    jwt(['res.id.user_id','res.id.jwt_session_id','res.id.sessions_ID']),
    create_cookie(['res.jwt.auth_token'],14,'year'),
    create_mailcode('email_verification','email'),
    hasher(['password']),
    register
);

route.post('/login',
    validator(['email','password']),
    hasher(['password']),
    db.validate_exist(User,{'emails.email':'email','emails.type':'account_email'},'password_or_email_not_correct',{type:'and',save_name:'user'}),
    check_condition('res.user',{password:'res.hash.password'},{status_name:'password'}),
    protecter('attempt_protecter'),
    create_mailcode('login_verification','email')
);

route.post('/resend/code/email',
    validator(['email']),
    auth_user(),
    check_condition('res.user.emails',{email:'email'},{error:'email_not_founded'}),
    check_condition('res.user.emails',{email:'email',verified:false},{error:'already_verified'}),
    db.delete_one(Code,{mail:'email',user_ID:'res.user.ID',type:'email_verification'}),
    create_mailcode('email_verification','email'),
    send_response('mailcode_resended',{ mailcode:'res.mail_code.ID'})
);

route.post('/verify/email',
    validator(['code','code_ID']),
    auth_user(),
    check_mailcode('email_verification','res.user.ID'),
    verify_email
);

route.post('/verify/login',
    validator(['code','code_ID','user_id']),
    db.validate_exist(User,{ID:'user_id'},'user_not_founded',{save_name:'user'}),
    check_mailcode('login_verification','res.user.ID'),
    create_id(['sessions_ID']),
    jwt(['req.body.user_id','res.user.jwt_session_id','res.id.sessions_ID']),
    create_cookie(['res.jwt.auth_token'],14,'year'),
    login
);