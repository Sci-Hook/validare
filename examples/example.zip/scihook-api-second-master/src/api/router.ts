import {route as user} from './routes/user';
import {route as lang} from './routes/lang';

import * as express from 'express';

export var router:any = express.Router();

router.use('/user' , user);
router.use('/lang' , lang);