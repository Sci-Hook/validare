import { utils } from '../../../../prexpress-v3';
import { code_types } from '../../../types/code_types';
import {Code} from '../../../../schemas/Codes';

var mails = {
    email_verification:{
        html:'email-htmls/account/verify-email.html',
        email:'verify-email'
    },
    login_verification:{
        html:'email-htmls/account/verify-login.html',
        email:'verify-login'
    }
};

export function create_mailcode(type:code_types,email_name:string) {

    return async (req,res,next ) => {


        var code = await utils.create_id('code');
        var ID = await utils.create_id('code_ID');
        var email_address = await utils.get_value(email_name,req,res);
        var mail = mails[type]
        
        var user_ID;

        if (res.id) {
            if(res.id.user_id){
                user_ID = res.id.user_id
            }
        }

        if (!user_ID) {
            user_ID = res.user.ID;
        }

        var created_code = new Code({
            code,
            create_date:Date.now(),
            expires:Date.now() + utils.get_date(5,'min'),
            ID,
            IP:req.ip,
            limit:3,
            type,
            user_ID,
            mail:email_address
        });
        
        res.mail_code = created_code;
        next();

        created_code.save();

        var html = await utils.create_html(mail.html,res.lang,{'#code':code});
        await utils.send_email(email_address,mail.email,res.lang,html);

    }

}