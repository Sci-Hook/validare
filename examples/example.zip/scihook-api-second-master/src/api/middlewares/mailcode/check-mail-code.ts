import { utils } from '../../../../prexpress-v3';
import { code_types } from '../../../types/code_types';
import {Code} from '../../../../schemas/Codes';

export function check_mailcode(type:code_types,user_id:string) {

    return async (req,res,next) => {

        var ID = req.body.code_ID;
        var user_ID = await utils.get_value(user_id,req,res);
        
        var code = await Code.findOne({ID,user_ID,type:type});

        if (!code) {
            return utils.send_response('code_not_founded',res);
        }

        if (code.IP) {
            if (code.IP !== req.ip) {
                return utils.send_response('location_error',res);         
            } 
        }
        
        if (code.expires) {
            if (code.expires <  Date.now()) {
                return utils.send_response('code_timeouted',res);         
            } 
        }

        if (code.code != req.body.code) {
            if (code.limit && code.limit > 0) {
                code.limit = code.limit - 1;
                code.save();
            }else{
                code.deleteOne();   
            }
            return utils.send_response('code_is_wrong',res);         
        }

        code.deleteOne();

        next();
    }
    
}