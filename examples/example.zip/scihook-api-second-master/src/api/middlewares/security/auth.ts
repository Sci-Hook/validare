import { send_response } from  '../../../../prexpress-v3/functions';
import * as jwt from 'jsonwebtoken';
import {User} from '../../../../schemas/User';

export  function auth_user() {

    return async (req,res,next) => {

        var keys = global.config.keys;

        if (!req.headers['authorization']) {
            return send_response('auth',res);
        }
    
        var token = req.headers['authorization'].split(' ')[1];
    
        if (!token) {

            return send_response('auth',res);
        }
    
        var key_info = keys['auth_token'];
        var hash_key = key_info.split(' ')[1];
    
        try {
            
            var decoded_data = jwt.verify(token,hash_key);
    
            var data = await User.findOne({
                ID:decoded_data.user_id,
                jwt_session_id:decoded_data.jwt_session_id        
            });
    
            if (data) {
    
                if (data?.sessions) {
                    data.sessions.syncFor(function (session ,next_session) {
                        if (session.sessions_ID == decoded_data.sessions_ID) {
                            if (session.active) {
                                res.user = data;
                                next();
                            }else{
                                return send_response('auth',res);
                            }   
                        }else{
                            next_session();
                        }
                    });
                } 
    
            }else{
                return send_response('auth',res);
            }
        
        } catch (error) {
            return send_response('auth',res);
        }
        
    }

}