import { utils } from "../../../../../../prexpress-v3";

export var levels = {
    1:{
        timeout:utils.get_date(5,'s'),
        max:3
    },
    2:{
        timeout:utils.get_date(7,'s'),
        max:3
    },
    3:{
        timeout:utils.get_date(8,'s'),
        max:3
    }
}