import {attempt_protecter} from './attempt-protecter';
import {Protecter} from '../../../../../schemas/Sci-protect';

import {function_type,protecter_types} from '../../../../types/protector-types';
import { utils } from '../../../../../prexpress-v3';

var functions:function_type = {
    attempt_protecter:attempt_protecter
}

export function protecter(type:protecter_types) {
    return async (req,res,next) => {

        var ip = await Protecter.findOne({IP:req.ip});

        if (!ip) {
            ip = new Protecter({IP:req.ip});
        }

        var status = await functions[type](req,res,ip);

        if (!status.status) {
            utils.send_response(status.message,res,status.data);
        }else{
            next();
        }

    }
}