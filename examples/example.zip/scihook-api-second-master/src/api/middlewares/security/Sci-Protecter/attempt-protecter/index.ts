import {levels} from './levels';
import {return_type} from '../../../../../types/protector-types';
import { utils } from '../../../../../../prexpress-v3';

var max_level = Object.keys(levels).length;

function set_ip(user,ip) {

    var IP_addresses = user.sci_protect.IP_addresses;

    return new Promise<boolean>((resolve, reject) => {

        IP_addresses.syncFor(function (IP,next_ip) {
            
            if (IP.IP == ip) {

                var i = IP_addresses.indexOf(IP);

                IP_addresses[i].count += 1;
                
          
                if(IP_addresses[i].count >= levels[IP_addresses[i].level].max){

                    if (IP_addresses[i].level >= max_level) {
                        IP_addresses[i].banned = true;
                    }
                    IP_addresses[i].timeout_time = Date.now() + levels[IP_addresses[i].level].timeout;
                    IP_addresses[i].count = 0;
                    IP_addresses[i].level += 1;

                    return resolve(true)

                }

                return resolve(false);
            }else{
                next_ip();
            }

        },async () => {
            //sadece hiç giriş yapmaya çalışmamış ise çalışıyor.
            IP_addresses.push({
                IP:ip,
                count:1,
                level:1
            });
            return resolve(false);
        });
    });
}

function check_ip(ips,ip) {
    return new Promise<{status:boolean,timeout?:number}>((resolve, reject) => {
        ips.syncFor(function (IP,next_ip) {
            if (IP.IP == ip) {

                if (IP.banned) {
                    return resolve({status:false,timeout:0})
                }

                if (IP.timeout_time > Date.now()) {
                    resolve({status:false,timeout:IP.timeout_time - Date.now()});
                }else{
                    resolve({status:true});
                }
            }else{
                next_ip();
            }
        },() => {
            resolve({status:true});
        });
    })
}

export function attempt_protecter(req,res,ip) {

    return new Promise<return_type>(async (resolve, reject) => {
        var user = res.user;
        var sci_protect = user.sci_protect;
    
        var status = await check_ip(sci_protect.IP_addresses,req.ip);

        if (!status.status) {
            return resolve({
                data:{timeout:status.timeout},
                status:status.status,
                message:'max_attempt'
            });
        }
    
        if (!res.password) {
            var timeout = await set_ip(user,req.ip);

            if (timeout) {
                var html = await utils.create_html('email-htmls/account/multiple-login-attempts.html',res.lang,{'#username':req.body.username});
                await utils.send_email(res.user.email,'try-login',res.lang,html)
            }

            user.save();

            return resolve({
                status:false,
                message:'password_or_email_not_correct'
            });
            
        }else{
            return resolve({
                status:status.status,
                message:'no_error'
            });
        }
    })
}