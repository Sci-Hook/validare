import { utils } from '../../../prexpress-v3';
import {User} from '../../../schemas/User';

export function controller(req,res,next) {
    
    var user =  new User({
        ID:res.id.user_id,
        username:req.body.username,
        created_at:Date.now(),
        sessions:[
            {
                active:true,
                IP:req.ip,
                sessions_ID:res.id.sessions_ID
            }
        ],
        name:req.body.name,
        emails:[{
            email:req.body.email,
            type:'account_email',
            change_limit:3,
            last_change_date:Date.now(),
            verified:false
        }],
        password:res.hash.password,
        verified:false,
        registiration_IP:req.ip,
        jwt_session_id:res.id.jwt_session_id,
        sci_protect:{
            count:0
        },
        date_of_birth:`${req.body['birth-day']}-${req.body['birth-month']}-${req.body['birth-year']}`
    });

    user.save();

    utils.send_response('register',res,{
        mailcode:res.mail_code.ID,
        jwt:res.jwt.auth_token
    });

}