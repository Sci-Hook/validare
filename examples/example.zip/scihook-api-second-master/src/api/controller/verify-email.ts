import { utils } from "../../../prexpress-v3";

export function controller(req,res,next) {
    
    var user =  res.user;
    var emails = user.emails;
    var mail = res.mail_code.mail;

    emails.forEach(email => {
        if (email.email == mail) {
            email.verified = true;
            user.save();
        }
    });
    
    utils.send_response('mail_verfication_complete',res);

}