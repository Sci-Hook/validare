
export function controller(req,res,next) {
    
    var user = res.user;

    user.sessions.push({
        IP:req.ip,
        sessions_ID:res.id.sessions_ID,
        active:true
    });

    user.save();

    res.json({
        token:res.jwt.auth_token
    })

}