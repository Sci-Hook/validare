export function send_information_email() {
    



}