export async function decrease_limit(schema) {
    if (schema.limit > 1) {
        schema.limit = schema.limit - 1;
        schema.save();
    }else{
        schema?.deleteOne();
    }
}