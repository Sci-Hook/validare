type protecter_types = 'attempt_protecter'
type return_type = {status:boolean,data?:any,message:'no_error'|'max_attempt'|'password_or_email_not_correct'};

type function_type = {
    attempt_protecter:(req:any,res:any,ip:any) => Promise<return_type>
}

export {
    protecter_types,
    function_type,
    return_type
}