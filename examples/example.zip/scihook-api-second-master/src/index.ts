import * as express from 'express';
import * as cookieParser from 'cookie-parser';
import {connect} from 'mongoose';
import {router as api} from './api/router';
import {accept_language,create_cookie,create_html,frontend_loader} from '../prexpress-v3';

connect('mongodb://127.0.0.1:27017/scihook');

var app:any = express();
app.set('view engine','ejs');

app.use(express.json());
app.use(cookieParser());
app.use(accept_language(['headers.location','cookies.location']));

frontend_loader(app);

app.use('/static',express.static('static'));
app.use('/api' , api);

app.use('/learn_language' , (req,res) => {
    res.send('<h1>'+req.headers['accept-language']+'</h1>')
});

app.listen(80);