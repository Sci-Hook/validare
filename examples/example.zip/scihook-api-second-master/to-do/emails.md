E-Mail HTML To-Do List

Account E-Mails
- [x] new-location.html
- [x] verify-email.html
- [x] verify-login.html
- [x] account-banned.html
- [ ] account-suspended.html
- [x] email-changed.html
- [x] multiple-login-attempts.html
- [x] password-change.html
- [x] phone-added.html
- [x] phone-removed.html
- [ ] recovery-email-added.html
- [ ] recovery-email-removed.html
- [x] username-changed.html

Milestone E-Mails
- [ ] birthday-1.html
- [ ] birthday-2.html
- [ ] registration-anniversary.html

Volunteering System E-Mails
- [ ] volunteer-account-created.html
- [ ] volunteer-account-delete-confirmation.html
- [ ] volunteer-account-deleted.html