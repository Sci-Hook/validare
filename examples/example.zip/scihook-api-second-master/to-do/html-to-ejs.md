HTML to EJS Texts To-Do List

- [x] main.ejs
- [x] register-page-1.ejs
- [x] register-page-2.ejs
- [x] register-page-3.ejs
- [x] login-page-1.ejs
- [x] login-page-2.ejs
- [x] account-management-center.ejs
- [x] privacy-and-security.ejs
- [x] account-settings.ejs
- [x] email-verification.ejs
- [ ] account-recovery-program-page-1.ejs
- [ ] account-recovery-program-page-2.ejs
- [ ] account-recovery-program-page-3.ejs
- [ ] account-recovery-program-page-4.ejs
- [ ] account-recovery-program-page-5.ejs
- [ ] account-recovery-program-page-6.ejs
- [ ] account-recovery-program-page-7.ejs
- [ ] account-recovery-program-page-8.ejs

HTML to EJS Image To-Do List

- [ ] main.ejs
- [ ] register-page-1.ejs
- [ ] register-page-2.ejs
- [ ] register-page-3.ejs
- [ ] login-page-1.ejs
- [ ] login-page-2.ejs
- [ ] account-management-center.ejs
- [ ] privacy-and-security.ejs
- [ ] account-settings.ejs
- [ ] email-verification.ejs
- [ ] account-recovery-program-page-1.ejs
- [ ] account-recovery-program-page-2.ejs
- [ ] account-recovery-program-page-3.ejs
- [ ] account-recovery-program-page-4.ejs
- [ ] account-recovery-program-page-5.ejs
- [ ] account-recovery-program-page-6.ejs
- [ ] account-recovery-program-page-7.ejs
- [ ] account-recovery-program-page-8.ejs

HTML to EJS Image Alt-Texts To-Do List

- [ ] main.ejs
- [ ] register-page-1.ejs
- [ ] register-page-2.ejs
- [ ] register-page-3.ejs
- [ ] login-page-1.ejs
- [ ] login-page-2.ejs
- [ ] account-management-center.ejs
- [ ] privacy-and-security.ejs
- [ ] account-settings.ejs
- [ ] email-verification.ejs
- [ ] account-recovery-program-page-1.ejs
- [ ] account-recovery-program-page-2.ejs
- [ ] account-recovery-program-page-3.ejs
- [ ] account-recovery-program-page-4.ejs
- [ ] account-recovery-program-page-5.ejs
- [ ] account-recovery-program-page-6.ejs
- [ ] account-recovery-program-page-7.ejs
- [ ] account-recovery-program-page-8.ejs